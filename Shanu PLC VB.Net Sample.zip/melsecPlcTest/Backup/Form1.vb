'created by shanu on 2007-07-10
'included the MelscPLc Dll in my Project
Imports MelsecPLC
Public Class Form1
    Inherits System.Windows.Forms.Form
    ' Dim winsock1 As MelsecPLC.Winsock
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    'created by shanu on 2007-07-10
    'included the winsock object creation in my Project
    Friend WithEvents Winsock1 As MelsecPLC.Winsock
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents BtnRead As System.Windows.Forms.Button
    Friend WithEvents btnWrite As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnConnect = New System.Windows.Forms.Button
        Me.BtnRead = New System.Windows.Forms.Button
        Me.btnWrite = New System.Windows.Forms.Button
        Me.Winsock1 = New MelsecPLC.Winsock
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(120, 48)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(104, 48)
        Me.btnConnect.TabIndex = 0
        Me.btnConnect.Text = "Connect"
        '
        'BtnRead
        '
        Me.BtnRead.Location = New System.Drawing.Point(120, 120)
        Me.BtnRead.Name = "BtnRead"
        Me.BtnRead.Size = New System.Drawing.Size(104, 48)
        Me.BtnRead.TabIndex = 1
        Me.BtnRead.Text = "Read"
        '
        'btnWrite
        '
        Me.btnWrite.Location = New System.Drawing.Point(120, 192)
        Me.btnWrite.Name = "btnWrite"
        Me.btnWrite.Size = New System.Drawing.Size(104, 48)
        Me.btnWrite.TabIndex = 2
        Me.btnWrite.Text = "Write"
        '
        'Winsock1
        '
        Me.Winsock1.LocalPort = 80
        Me.Winsock1.RemoteIP = "110.120.0.200"
        Me.Winsock1.RemotePort = 8192
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(88, 0)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(208, 20)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = ""
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 326)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnWrite)
        Me.Controls.Add(Me.BtnRead)
        Me.Controls.Add(Me.btnConnect)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        Try
            'created by shanu on 2007-07-10
            'using the object we call the function for connection establishment of winsock1
            '''Winsock1.LocalPort = 80
            '''Winsock1.RemoteIP = "110.120.0.200"
            '''Winsock1.RemotePort = 8192
            Winsock1.Connect()
        Catch ex As Exception
        End Try
    End Sub
    Private Sub BtnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRead.Click
        Try
            'created by shanu on 2007-07-10
            'using the object we send the data as string to read data
            Dim cmd As String
            cmd = ""
            cmd = cmd & "5000"                 ' sub head (not change)
            cmd = cmd & "00"                   ' network number (not change)
            cmd = cmd & "FF"                   ' PLC number (not change)
            cmd = cmd & "03FF"                 ' I/O number (not change)
            cmd = cmd & "00"                   ' (not change)
            cmd = cmd & "0018"                 ' length of demand data (change)
            cmd = cmd & "000A"                 ' CPU INSPECTOR DATA 
            cmd = cmd & "0401"                 ' READ COMMAND
            cmd = cmd & "0000"                 ' SUB COMMAND
            cmd = cmd & "D*"                   ' DEVICE CODE
            cmd = cmd & "000100"  'adBase       ' BASE ADDRESS
            cmd = cmd & "0001"
            Winsock1.Send(cmd)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub btnWrite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWrite.Click
        Try
            'created by shanu on 2007-07-10
            'using the object we send the data as string to write data
            Dim out2, cmd As String
            out2 = "0001"
            cmd = ""
            cmd = cmd & "5000"                 ' sub HEAD (NOT)
            cmd = cmd & "00"                   ' network number (NOT)
            cmd = cmd & "FF"                   ' PLC NUMBER
            cmd = cmd & "03FF"                 ' DEMAND OBJECT MUDULE I/O NUMBER
            cmd = cmd & "00"                   ' DEMAND OBJECT MUDULE DEVICE NUMBER
            cmd = cmd & "001C"                 ' Length of demand data
            cmd = cmd & "000A"                 ' CPU inspector data
            cmd = cmd & "1401"                 ' Write command
            cmd = cmd & "0000"                 ' Sub command
            cmd = cmd & "D*"                   ' device code
            cmd = cmd & "000101" 'adBase                 ' base address
            cmd = cmd & "0001"                 ' device number
            cmd = cmd & out2
            Winsock1.Send(cmd)
        Catch ex As Exception
        End Try
    End Sub
    'created by shanu on 2007-07-10
    'this event triger and raise when the data from  plc send data from plc to pc
    Private Sub Winsock1_DataArrival(ByVal sender As MelsecPLC.Winsock, ByVal BytesTotal As Integer) Handles Winsock1.DataArrival
        Try
           
            Dim s As String
            'created by shanu on 2007-07-10
            'the winsock1.getdata return the data from plc
            Winsock1.GetData(s)
            TextBox1.Text = s
            ' MsgBox(s)
        Catch ex As Exception

        End Try
    End Sub
End Class
