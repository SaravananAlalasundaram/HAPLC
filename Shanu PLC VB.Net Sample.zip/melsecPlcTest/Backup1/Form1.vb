'created by shanu on 2007-07-10
'included the MelscPLc Dll in my Project
Imports MelsecPLC
Public Class Form1
    Inherits System.Windows.Forms.Form
    ' Dim winsock1 As MelsecPLC.Winsock
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    'created by shanu on 2007-07-10
    'included the winsock object creation in my Project
    Friend WithEvents Winsock1 As MelsecPLC.Winsock
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents BtnRead As System.Windows.Forms.Button
    Friend WithEvents btnWrite As System.Windows.Forms.Button
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("01")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("02")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("03")
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("04")
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("05")
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("06")
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("07")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("08")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("09")
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("10")
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("11")
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("12")
        Dim TreeNode13 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("13")
        Dim TreeNode14 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("14")
        Dim TreeNode15 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("15")
        Dim TreeNode16 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("16")
        Dim TreeNode17 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Input", -2, -2, New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2, TreeNode3, TreeNode4, TreeNode5, TreeNode6, TreeNode7, TreeNode8, TreeNode9, TreeNode10, TreeNode11, TreeNode12, TreeNode13, TreeNode14, TreeNode15, TreeNode16})
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnConnect = New System.Windows.Forms.Button
        Me.BtnRead = New System.Windows.Forms.Button
        Me.btnWrite = New System.Windows.Forms.Button
        Me.Winsock1 = New MelsecPLC.Winsock
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(50, 202)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(104, 48)
        Me.btnConnect.TabIndex = 0
        Me.btnConnect.Text = "Connect"
        '
        'BtnRead
        '
        Me.BtnRead.Location = New System.Drawing.Point(160, 202)
        Me.BtnRead.Name = "BtnRead"
        Me.BtnRead.Size = New System.Drawing.Size(104, 48)
        Me.BtnRead.TabIndex = 1
        Me.BtnRead.Text = "Read"
        '
        'btnWrite
        '
        Me.btnWrite.Location = New System.Drawing.Point(270, 202)
        Me.btnWrite.Name = "btnWrite"
        Me.btnWrite.Size = New System.Drawing.Size(104, 48)
        Me.btnWrite.TabIndex = 2
        Me.btnWrite.Text = "Write"
        '
        'Winsock1
        '
        Me.Winsock1.LocalPort = 80
        Me.Winsock1.RemoteIP = "110.120.0.200"
        Me.Winsock1.RemotePort = 8192
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 12)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(432, 20)
        Me.TextBox1.TabIndex = 3
        '
        'TreeView1
        '
        Me.TreeView1.CheckBoxes = True
        Me.TreeView1.Location = New System.Drawing.Point(50, 282)
        Me.TreeView1.Name = "TreeView1"
        TreeNode1.Name = "Node9"
        TreeNode1.Text = "01"
        TreeNode2.Name = "Node10"
        TreeNode2.Text = "02"
        TreeNode3.Name = "Node11"
        TreeNode3.Text = "03"
        TreeNode4.Name = "Node12"
        TreeNode4.Text = "04"
        TreeNode5.Name = "Node13"
        TreeNode5.Text = "05"
        TreeNode6.Name = "Node14"
        TreeNode6.Text = "06"
        TreeNode7.Name = "Node15"
        TreeNode7.Text = "07"
        TreeNode8.Name = "Node16"
        TreeNode8.Text = "08"
        TreeNode9.Name = "Node17"
        TreeNode9.Text = "09"
        TreeNode10.Name = "Node18"
        TreeNode10.Text = "10"
        TreeNode11.Name = "Node19"
        TreeNode11.Text = "11"
        TreeNode12.Name = "Node20"
        TreeNode12.Text = "12"
        TreeNode13.Name = "Node21"
        TreeNode13.Text = "13"
        TreeNode14.Name = "Node22"
        TreeNode14.Text = "14"
        TreeNode15.Name = "Node23"
        TreeNode15.Text = "15"
        TreeNode16.Name = "Node24"
        TreeNode16.Text = "16"
        TreeNode17.Checked = True
        TreeNode17.ImageIndex = -2
        TreeNode17.Name = "Node8"
        TreeNode17.SelectedImageIndex = -2
        TreeNode17.Text = "Input"
        Me.TreeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode17})
        Me.TreeView1.Size = New System.Drawing.Size(104, 292)
        Me.TreeView1.StateImageList = Me.ImageList1
        Me.TreeView1.TabIndex = 4
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "grayGlow.JPG")
        Me.ImageList1.Images.SetKeyName(1, "greenGlow.JPG")
        Me.ImageList1.Images.SetKeyName(2, "orangeGlow.JPG")
        Me.ImageList1.Images.SetKeyName(3, "redGlow.JPG")
        '
        'Timer1
        '
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(12, 66)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(432, 20)
        Me.TextBox2.TabIndex = 5
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 623)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TreeView1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnWrite)
        Me.Controls.Add(Me.BtnRead)
        Me.Controls.Add(Me.btnConnect)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region
    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        Try
            'created by shanu on 2007-07-10
            'using the object we call the function for connection establishment of winsock1
            '''Winsock1.LocalPort = 80
            Winsock1.RemoteIP = "100.100.160.1" '"110.120.0.200"
            '''Winsock1.RemotePort = 8192
            Winsock1.Connect()
            '   If Winsock1.GetState = WinsockStates.Connecting Then
            MessageBox.Show("connected:")
            ''Else
            ''MessageBox.Show("Not Connected")
            ''End If
            Timer1.Enabled = True
            Timer1.Start()
        Catch ex As Exception
        End Try
    End Sub
    Private Sub BtnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRead.Click
        Try
            'created by shanu on 2007-07-10
            'using the object we send the data as string to read data
            Dim cmd As String
            cmd = ""
            cmd = cmd & "5000"                 ' sub head (not change)
            cmd = cmd & "00"                   ' network number (not change)
            cmd = cmd & "FF"                   ' PLC number (not change)
            cmd = cmd & "03FF"                 ' I/O number (not change)
            cmd = cmd & "00"                   ' (not change)
            cmd = cmd & "0018"                 ' length of demand data (change)
            cmd = cmd & "000A"                 ' CPU INSPECTOR DATA 
            cmd = cmd & "0401"                 ' READ COMMAND
            cmd = cmd & "0000"                 ' SUB COMMAND
            cmd = cmd & "D*"                   ' DEVICE CODE
            cmd = cmd & "9880"  'adBase       ' BASE ADDRESS
            cmd = cmd & "0001"
            Winsock1.Send(cmd)
        Catch ex As Exception
        End Try
    End Sub
    Private Sub btnWrite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWrite.Click
        Try
            'created by shanu on 2007-07-10
            'using the object we send the data as string to write data
            Dim out2, cmd As String
            out2 = "0001"
            cmd = ""
            cmd = cmd & "5000"                 ' sub HEAD (NOT)
            cmd = cmd & "00"                   ' network number (NOT)
            cmd = cmd & "FF"                   ' PLC NUMBER
            cmd = cmd & "03FF"                 ' DEMAND OBJECT MUDULE I/O NUMBER
            cmd = cmd & "00"                   ' DEMAND OBJECT MUDULE DEVICE NUMBER
            cmd = cmd & "001C"                 ' Length of demand data
            cmd = cmd & "000A"                 ' CPU inspector data
            cmd = cmd & "1401"                 ' Write command
            cmd = cmd & "0000"                 ' Sub command
            cmd = cmd & "D*"                   ' device code
            cmd = cmd & "9880" 'adBase                 ' base address
            cmd = cmd & "0001"                 ' device number
            cmd = cmd & out2
            Winsock1.Send(cmd)
        Catch ex As Exception
        End Try
    End Sub
    'created by shanu on 2007-07-10
    'this event triger and raise when the data from  plc send data from plc to pc
    Dim sname As String = ""
    Private Sub Winsock1_DataArrival(ByVal sender As MelsecPLC.Winsock, ByVal BytesTotal As Integer) Handles Winsock1.DataArrival
        Try
            Dim s As String
            'created by shanu on 2007-07-10
            'the winsock1.getdata return the data from plc
            Winsock1.GetData(s)
            sname = s.ToString()
            'textname()
            'TextBox1.Text = sname
            MsgBox(s)
        Catch ex As Exception
        End Try
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not sname = String.Empty Then
            TextBox1.Text = sname
            TextBox2.Text = Asc(sname)
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
