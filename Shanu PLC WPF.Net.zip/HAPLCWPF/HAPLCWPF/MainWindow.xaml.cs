﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.IO.Ports;
using System.Windows.Threading;
using System.Data;
using System.IO;

using Microsoft.Win32;
using MelsecPLC;
namespace HAPLCWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MelsecPLC.Winsock winsock1;

        public MelsecPLC.Winsock winsock2;

        //private RamaSocket.SocketLib m_Socket_Elec = new RamaSocket.SocketLib();
        //private String IP_PLC = "10.126.224.221";
        //private Int32 IP_Port = 8000;
        DispatcherTimer timer = new DispatcherTimer();



        private String m_Sent = String.Empty;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
             winsock1 = new MelsecPLC.Winsock();
                     winsock1.LocalPort = 1027;
                    
                     winsock1.RemoteIP = "10.126.224.221";
                     int a = 8000;

                     winsock1.RemotePort = 8000;
            winsock1.Connect();

            winsock1.DataArrival += new MelsecPLC.Winsock.DataArrivalEventHandler(winsock1_DataArrival);
            timer.Interval = TimeSpan.FromMilliseconds(1000);
            timer.IsEnabled = true;
            timer.Tick += timer1_Tick;


            timer.Start();
        }
        private void winsock1Connect()
        {
            try
            {
                try
                {
                    winsock1.Close();
                    //winsock1.Dispose();
                }
                catch (Exception ex)
                {
                }

                winsock1.LocalPort = 1027;

                winsock1.RemoteIP = "10.126.224.221";
                int a = 8000;

                winsock1.RemotePort = 8000;
                winsock1.Connect();
            }
            catch (Exception ex)
            {
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                String cmd = "500000FF03FF000018000A04010000D*0095000001";
                winsock1.Send(cmd);
                label2.Content = DateTime.Now.ToString("HH:mm:ss");
                try
                {
                   
                    //   lblDay.Text = DateTime.Now.DayOfWeek.ToString();
                   

                    if (winsock1.GetState.ToString() != "Connected")
                    {

                        winsock1Connect();

                    }
                }
                catch (Exception ex)
                {
                }
                if (Jig01 != String.Empty)
                {
                    label1.Content = Jig01;
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void winsock1_DataArrival(MelsecPLC.Winsock sender, int BytesTotal)
        {
            String s = String.Empty;

            winsock1.GetData(ref s);
            Jig01 = s;

            

        }
        String Jig01 = String.Empty;
    }

}
